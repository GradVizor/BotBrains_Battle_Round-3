''' BotBrains_Round_3:-

    This following code is to detect green colour by first haulting at a given coordinate
    in order to process its dimensions to confirm it to be 15x15x15 cm '''

import time
from dronekit import connect, VehicleMode, LocationGlobalRelative, Command, LocationGlobal
from pymavlink import mavutil
import cv2
import numpy as np

''' In this code I'm assuming that some coordinates are given for each UAV (among the three)
    to detect green colour and the provided coordinates are unique for each UAV, to encounter 
    the error of clashing among the three.
    
    I'm providing some pseudo coordinates are given only for an example and can be replaced
    as per the requirements.
    to detect green colour.'''

dummy_point1 = [-30.3629198, 150.1651535,30]
dummy_point2 = [-30.3627360, 150.1647351,30]
dummy_point3 = [-30.3629416, 150.1641772,30]
dummy_point4 = [-30.3639522, 150.1649336,30]

original_hotspot1 = [15.394484151126512, 75.73128900282778]
original_hotspot2 = [15.394433365359202, 75.73159701736482]
original_hotspot3 = [15.393648277167763, 75.7313608026834]
original_hotspot4 = [15.393939800670632, 75.73111960138523]

original_target = [15.393869642622231, 75.73141168658405]

connection_string='/dev/ttyACM0'
print('Connecting...')
vehicle = connect(connection_string,baud=57600,wait_ready=True)

#-- Setup the commanded flying speed

ground_speed = 0.75 # [m/s]

#-- Define arm and takeoff
def arm_and_takeoff(altitude):

   while not vehicle.is_armable:
      print("waiting to be armable")
      time.sleep(1)

   print("Arming motors")
   vehicle.mode = VehicleMode("GUIDED")
   vehicle.armed = True

   while not vehicle.armed: time.sleep(1)

   print("Taking Off")
   vehicle.simple_takeoff(altitude)

   while True:
      v_alt = vehicle.location.global_relative_frame.alt
      print(">> Altitude = %.1f m"%v_alt)
      if v_alt >= altitude*0.95:
          print("Target altitude reached")
          break
      time.sleep(1)
 #-- Define the function for sending mavlink velocity command in body frame
def set_velocity_body(vx, vy, vz):
    """ Remember: vz is positive downward!!!
    http://ardupilot.org/dev/docs/copter-commands-in-guided-mode.html
    
    Bitmask to indicate which dimensions should be ignogreen by the vehicle 
    (a value of 0b0000000000000000 or 0b0000001000000000 indicates that 
    none of the setpoint dimensions should be ignogreen). Mapping:""" 
    msg = vehicle.message_factory.set_position_target_local_ned_encode(
            0,
            0, 0,
            mavutil.mavlink.MAV_FRAME_BODY_OFFSET_NED,
            0b0000111111000111, #-- BITMASK -> Consider only the velocities
            0, 0, 0,        #-- POSITION
            vx, vy, vz,     #-- VELOCITY
            0, 0, 0,        #-- ACCELERATIONS
            0, 0)
    vehicle.send_mavlink(msg)
    vehicle.flush()


def Dectection():

    cap = cv2.VideoCapture("IP address from where you want to get the camera feed")
    #cap = nano.Camera(flip=0, width=640, height = 480, fps=30)

    last_detection_time = time.time()

    # Set a minimum area threshold
    min_area = 100 # Adjust this value as needed

    frame_rate = cap.get(cv2.CAP_PROP_FPS)
    frame_interval = int(frame_rate)  # Capture one frame per second

    frame_count = 0

    while True:
        # Read a frame from the video
        ret,frame = cap.read()

        #frame_photo = frame.copy()
        frame_rate = cap.get(cv2.CAP_PROP_FPS)
        frame_interval = int(frame_rate)  # Capture one frame per second
        frame_count = 0

        # Convert the frame to the HSV color space
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        frame = cv2.line(frame, (320,0), (320,480), (0,250,0), 2)
        frame = cv2.line(frame, (0,240), (640,240), (0,250,0), 2)

        # Define the lower and upper HSV values for green color detection
        lower_green = np.array([35, 100, 100])
        upper_green = np.array([85, 255, 255])
        mask_1 = cv2.inRange(hsv, lower_green, upper_green)

        # Create a mask to isolate the green pixels
        mask = mask_1
        # Find contours in the mask
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        # Loop through the detected contours and filter rectangular ones with a minimum area
        for contour in contours:
            last_detection_time = time.time()
            #target_contour = max(contours, key=cv2.contourArea)
            x, y, w, h = cv2.boundingRect(contour)
            #x, y, w, h = cv2.boundingRect(target_contour)
            aspect_ratio = float(w) / h
            contour_area = cv2.contourArea(contour)
            #contour_area = cv2.contourArea(target_contour)
            if 0.5 < aspect_ratio < 1.6 and contour_area > min_area:
                # This contour is approximately rectangular and has an area greater than the threshold
                frame = cv2.rectangle(frame, (x,y), (x+w, y+h), (0,255,255), 2)
                getX = (x + (x+w))/2
                getY = (y + (y+h))/2
                if (getX < 285):
                    print("LEFT")
                    set_velocity_body(0, -ground_speed, 0)
                    break
                if (getX > 365):
                    print("RIGHT")
                    set_velocity_body(0, ground_speed, 0)
                    break
                if (getY<190):
                    print("FORWARD")
                    set_velocity_body(ground_speed, 0, 0)
                    break
                if (getY>320):
                    print("BACKWARD")
                    set_velocity_body(-ground_speed, 0, 0)
                    break
                if(380>getX>285 and 320>getY>190):
                    set_velocity_body(0, 0, 0)
                    time.sleep(5)
                    cap.release()
                    cv2.destroyAllWindows()
                    return                   

        time_since_last_detection = time.time() - last_detection_time   
        if time_since_last_detection >= 3:
            print("Not Detected", "MODE: BRAKE") 
            cap.release()
            cv2.destroyAllWindows()
            return
            #vehicle.mode = VehicleMode("BRAKE") 
        # Display the frame with detected green rectangular objects
        # Break the loop when the 'q' key is pressed
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    # Release the video capture and close the window
    cap.release()
    cv2.destroyAllWindows()

arm_and_takeoff(30)
time.sleep(1)
print("Hold position for 2 seconds")

vehicle.simple_goto(LocationGlobalRelative(original_target[0], original_target[1], 20))
time.sleep(30)
Dectection()

vehicle.simple_goto(LocationGlobalRelative(original_hotspot4[0], original_hotspot4[1],10))
time.sleep(15)
Dectection()

vehicle.simple_goto(LocationGlobalRelative(original_hotspot3[0], original_hotspot3[1],10))
time.sleep(15)
Dectection()

vehicle.simple_goto(LocationGlobalRelative(original_hotspot2[0], original_hotspot2[1],10))
time.sleep(15)
Dectection()

vehicle.simple_goto(LocationGlobalRelative(original_hotspot1[0], original_hotspot1[1],10))
time.sleep(15)
Dectection()

# vehicle.simple_goto(LocationGlobalRelative(dummy_point3[0], dummy_point3[1],10))
# time.sleep(1)
# Dectection()
time.sleep(1)
vehicle.mode=VehicleMode("RTL")
time.sleep(5)
vehicle.close()


#vehicle.mode = VehicleMode("RTL")
#vehicle.close()